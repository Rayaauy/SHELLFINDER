<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="title" content="Hacked By 101CISAMM"/>
    <meta name="description" content="Your security got rekt!"/>
    <meta name="keywords" content="hacked, Sphinx101, 101CISAMM, cybersecurity"/>
    <meta name="author" content="101CISAMM"/>
    <title>Hacked by 101CISAMM</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #1a1a1a;
            font-family: 'Courier New', Courier, monospace;
            overflow: hidden;
        }
        .container {
            text-align: center;
            color: #ff4040;
            text-shadow: 0 0 10px #ff4040;
        }
        h1 {
            font-size: 3em;
            animation: glitch 1s linear infinite;
        }
        p {
            font-size: 1.2em;
            color: #e0e0e0;
        }
        .blink {
            animation: blink 1s step-end infinite;
        }
        @keyframes glitch {
            2%, 64% { transform: translate(2px, 0); }
            4%, 60% { transform: translate(-2px, 0); }
            62% { transform: translate(0, 0) skew(5deg); }
        }
        @keyframes blink {
            50% { opacity: 0; }
        }
        img { border-radius: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <img alt="Sleeping Lego" src="https://i.ibb.co.com/QjC7c0qh/cape.jpg" style="max-width: 250px; display:block; margin: 20px auto; filter: drop-shadow(0 0 10px red);"/>
        <h1>HACKED BY 101CISAMM</h1>
        <p class="blink">You sleep peacefully, but your safety is threatened.<br> Wake up, before everything is destroyed.</p>
    </div>
</body>
</html>
